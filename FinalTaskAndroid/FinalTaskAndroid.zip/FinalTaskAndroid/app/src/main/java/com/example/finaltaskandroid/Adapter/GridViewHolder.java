package com.example.finaltaskandroid.Adapter;

import android.view.View;

public interface GridViewHolder {
    void onClick(View view);
}
